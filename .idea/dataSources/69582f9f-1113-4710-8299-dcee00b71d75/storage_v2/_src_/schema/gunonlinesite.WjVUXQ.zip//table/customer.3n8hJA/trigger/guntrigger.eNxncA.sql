create definer = saurav@`%` trigger gunTrigger
    after insert
    on customer
    for each row
begin
     insert into customerRole(userName ,role) values (new.userName,'ROLE_USER');
    end;

