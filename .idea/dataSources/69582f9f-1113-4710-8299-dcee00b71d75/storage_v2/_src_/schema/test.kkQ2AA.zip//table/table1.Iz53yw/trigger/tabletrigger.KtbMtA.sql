create definer = saurav@`%` trigger TableTrigger
    after insert
    on table1
    for each row
begin
     insert into Table2(id, name) values (new.id, new.name);
    end;

